
import { GoogleGenAI, Type } from "@google/genai";
import { NewsItem } from "../types";

export const generateMoreNews = async (currentRank: string): Promise<NewsItem[]> => {
  try {
    // Instantiate GoogleGenAI inside the function to ensure the most up-to-date API key is used from the environment.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Using gemini-3-pro-preview as generating subtle hoaxes and structured logic is a complex reasoning task.
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Bertindaklah sebagai 'Database Arsip Berita Nasional'. Hasilkan 10 item berita baru (Bahasa Indonesia) untuk game verifikasi 'CyberShield'.
      
      ATURAN KONTEN:
      1. Variasikan kategori: Kesehatan, Politik, Teknologi, Hiburan, Kripto, Bencana Alam, dan Lowongan Kerja.
      2. Berikan 5 Berita Fakta (FACT) dan 5 Berita Hoax (HOAX).
      3. Hoax harus memiliki indikator halus: URL .xyz/.top/.info, bahasa hiperbolis, sumber anonim, atau klaim tidak logis.
      4. Fakta harus menggunakan domain .go.id, .ac.id, atau media mainstream (.com/.id ternama) dengan bahasa netral.
      5. Pastikan Headline dan Konten terasa sangat realistik sesuai dengan tren di Indonesia saat ini.
      6. Jangan mengulang berita yang umum, buatlah skenario spesifik.

      Tingkat Kesulitan: ${currentRank}. Semakin tinggi pangkat, buat hoax semakin sulit dideteksi (perbedaan URL tipis).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              headline: { type: Type.STRING },
              source: { type: Type.STRING },
              url: { type: Type.STRING },
              content: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['FACT', 'HOAX'] },
              explanation: { type: Type.STRING },
              indicators: { 
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
            },
            required: ['id', 'headline', 'source', 'url', 'content', 'type', 'explanation', 'indicators']
          }
        }
      }
    });

    // Directly access the text property as a string.
    const text = response.text;
    if (!text) {
      console.warn("AI returned an empty response.");
      return [];
    }

    const newsData = JSON.parse(text.trim());
    return newsData.map((item: any) => ({
      ...item,
      // Using substring instead of the deprecated substr for unique ID generation.
      id: `gen-${Math.random().toString(36).substring(2, 11)}`,
      imageUrl: `https://picsum.photos/seed/${Math.random()}/600/400`
    }));
  } catch (error) {
    console.error("Error generating news:", error);
    return [];
  }
};

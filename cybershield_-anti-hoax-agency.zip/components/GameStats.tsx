
import React from 'react';
import { PlayerStats } from '../types';
import { GAME_ASSETS } from '../assets';

interface GameStatsProps {
  stats: PlayerStats;
}

const GameStats: React.FC<GameStatsProps> = ({ stats }) => {
  return (
    <div className="p-5 pb-4 bg-slate-900/90 border-b border-slate-800/50 backdrop-blur-md z-40 flex flex-col gap-4">
      <div className="flex justify-between items-start">
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 mb-1">
            <img src={GAME_ASSETS.SCORE_LABEL} className="w-4 h-4 opacity-70" alt="Score Label" />
            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">CURRENT_SCORE</span>
          </div>
          <span className="text-2xl font-black text-white font-mono tracking-tighter leading-none">
            {stats.score.toLocaleString()}
          </span>
        </div>
        <div className="text-right flex flex-col items-end">
          <span className="text-[7px] font-black text-slate-500 uppercase tracking-widest mb-1">AGENCY_CLEARANCE</span>
          <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2.5 py-1.5 rounded-lg border border-blue-500/20 shadow-sm">
            {stats.rank}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Battery / Power */}
        <div className="bg-slate-950/50 p-3 rounded-2xl border border-slate-800/50">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[8px] font-black text-slate-500 uppercase tracking-wider">BATTERY</span>
            <span className={`text-[10px] font-mono font-bold ${stats.battery < 30 ? 'text-red-500 animate-pulse' : 'text-emerald-400'}`}>
              {stats.battery}%
            </span>
          </div>
          <div className="h-1.5 bg-slate-900 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-1000 ${stats.battery < 30 ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' : 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]'}`}
              style={{ width: `${stats.battery}%` }}
            />
          </div>
        </div>

        {/* Calmness / Stability */}
        <div className="bg-slate-950/50 p-3 rounded-2xl border border-slate-800/50">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[8px] font-black text-slate-500 uppercase tracking-wider">STABILITY</span>
            <span className="text-[10px] font-mono font-bold text-blue-400">{stats.calmIndex}%</span>
          </div>
          <div className="h-1.5 bg-slate-900 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.4)] transition-all duration-1000"
              style={{ width: `${stats.calmIndex}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameStats;

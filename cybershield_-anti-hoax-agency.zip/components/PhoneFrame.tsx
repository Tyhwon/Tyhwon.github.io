
import React from 'react';
import { GAME_ASSETS } from '../assets';

interface PhoneFrameProps {
  children: React.ReactNode;
}

const PhoneFrame: React.FC<PhoneFrameProps> = ({ children }) => {
  return (
    <div className="relative mx-auto w-[450px] h-[900px] flex items-center justify-center transition-all duration-500">
      {/* Bodi Ponsel (Frame) */}
      <img 
        src={GAME_ASSETS.PHONE_FRAME} 
        className="absolute inset-0 w-full h-full object-contain pointer-events-none z-0 scale-[1.12]" 
        alt="Phone Frame" 
      />
      
      {/* Area Layar (Konten Game) - Disesuaikan ke 350x760 agar pas di layar */}
      <div className="relative w-[350px] h-[760px] bg-black overflow-hidden z-10 flex flex-col rounded-[42px] -mt-1 shadow-[0_0_50px_rgba(0,0,0,0.9)] border-[7px] border-slate-900/60">
        <div className="flex-1 overflow-hidden relative flex flex-col">
          {children}
        </div>
      </div>
    </div>
  );
};

export default PhoneFrame;


import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The Gemini API key is managed externally and available via process.env.API_KEY.
// We remove manual environment loading and 'define' blocks to follow guidelines.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
  },
});

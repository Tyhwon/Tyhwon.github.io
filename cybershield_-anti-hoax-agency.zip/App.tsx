
import React, { useState, useEffect, useCallback, useRef } from 'react';
import PhoneFrame from './components/PhoneFrame';
import GameStats from './components/GameStats';
import { GameState, Rank, PlayerStats, NewsItem } from './types';
import { INITIAL_NEWS, RANK_THRESHOLDS } from './constants';
import { GAME_ASSETS } from './assets';
import { generateMoreNews } from './services/gemini';
import { 
  RefreshCw, 
  ChevronRight, 
  AlertCircle, 
  Power, 
  Image as ImageIcon, 
  CheckCircle2, 
  ShieldAlert, 
  X, 
  LogOut, 
  Volume2, 
  VolumeX, 
  Play, 
  Settings, 
  Skull 
} from 'lucide-react';

const ImageWithFallback: React.FC<{ src: string; alt: string; className?: string }> = ({ src, alt, className = "" }) => {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const layoutClasses = className.replace(/object-\w+/g, '').trim();
  const imageClasses = className.match(/object-\w+/g)?.join(' ') || '';

  if (error) {
    return (
      <div className={`${layoutClasses} bg-slate-800 flex flex-col items-center justify-center border border-slate-700 text-slate-500 gap-2 rounded-xl`}>
        <ImageIcon size={20} />
        <span className="text-[9px] uppercase font-black tracking-widest">{alt}</span>
      </div>
    );
  }

  return (
    <div className={`${layoutClasses} relative overflow-hidden`}>
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900 z-10">
          <RefreshCw size={24} className="text-blue-500 animate-spin opacity-50" />
        </div>
      )}
      <img 
        src={src} 
        alt={alt} 
        className={`w-full h-full ${imageClasses} transition-opacity duration-300 ${loading ? 'opacity-0' : 'opacity-100'}`} 
        onLoad={() => setLoading(false)}
        onError={() => {
          setLoading(false);
          setError(true);
        }} 
      />
    </div>
  );
};

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [newsStack, setNewsStack] = useState<NewsItem[]>(INITIAL_NEWS);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [scale, setScale] = useState(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [stats, setStats] = useState<PlayerStats>({
    score: 0,
    battery: 100,
    calmIndex: 100,
    correctStreak: 0,
    rank: Rank.NOVICE
  });
  
  const [lastCorrection, setLastCorrection] = useState<NewsItem | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [exitDirection, setExitDirection] = useState<'left' | 'right' | null>(null);
  const [feedback, setFeedback] = useState<{ text: string, type: 'plus' | 'minus' } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Dynamic Scaling Logic
  useEffect(() => {
    const handleResize = () => {
      // Base dimensions of the PhoneFrame are roughly 450x900
      const baseWidth = 450;
      const baseHeight = 900;
      const padding = 20;
      
      const scaleX = (window.innerWidth - padding) / baseWidth;
      const scaleY = (window.innerHeight - padding) / baseHeight;
      
      // Use the minimum scale to ensure it fits, but capped at reasonable desktop size
      const newScale = Math.min(scaleX, scaleY, 1.1); 
      setScale(newScale);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Audio Initialization
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio(GAME_ASSETS.GAMEPLAY_BGM);
      audioRef.current.loop = true;
      audioRef.current.volume = 0.3;
    }

    const handlePlay = () => {
      if (audioRef.current && (gameState === GameState.PLAYING || gameState === GameState.MENU) && !isMuted) {
        audioRef.current.play().catch(() => {});
      }
    };

    handlePlay();
    window.addEventListener('mousedown', handlePlay, { once: true });

    if (isMuted || gameState === GameState.SHUTDOWN) {
      audioRef.current.pause();
    }

    return () => {
      window.removeEventListener('mousedown', handlePlay);
    };
  }, [gameState, isMuted]);

  useEffect(() => {
    const newRank = [...RANK_THRESHOLDS].reverse().find(t => stats.score >= t.score);
    if (newRank && newRank.rank !== stats.rank) {
      setStats(prev => ({ ...prev, rank: newRank.rank }));
    }
  }, [stats.score, stats.rank]);

  useEffect(() => {
    const remaining = newsStack.length - currentCardIndex;
    if (gameState === GameState.PLAYING && remaining < 4 && !isGenerating) {
      loadMoreNews();
    }
  }, [currentCardIndex, newsStack.length, gameState]);

  const loadMoreNews = async () => {
    setIsGenerating(true);
    try {
      const moreNews = await generateMoreNews(stats.rank);
      if (moreNews && moreNews.length > 0) {
        setNewsStack(prev => [...prev, ...moreNews]);
      } else {
        const recycled = [...INITIAL_NEWS].sort(() => Math.random() - 0.5);
        setNewsStack(prev => [...prev, ...recycled]);
      }
    } catch (e) {
      const recycled = [...INITIAL_NEWS].sort(() => Math.random() - 0.5);
      setNewsStack(prev => [...prev, ...recycled]);
    } finally {
      setIsGenerating(false);
    }
  };

  const startGame = () => {
    setIsProcessing(false);
    setExitDirection(null);
    setCurrentCardIndex(0);
    setNewsStack([...INITIAL_NEWS].sort(() => Math.random() - 0.5));
    setStats({
      score: 0,
      battery: 100,
      calmIndex: 100,
      correctStreak: 0,
      rank: Rank.NOVICE
    });
    setGameState(GameState.PLAYING);
  };

  const toggleMute = () => setIsMuted(prev => !prev);

  const exitGame = () => {
    if (confirm("Hentikan sesi verifikasi?")) {
      setGameState(GameState.MENU);
    }
  };

  const showFeedback = (text: string, type: 'plus' | 'minus') => {
    setFeedback({ text, type });
    setTimeout(() => setFeedback(null), 800);
  };

  const handleDecision = (decision: 'FACT' | 'HOAX') => {
    if (isProcessing) return;
    
    const currentNews = newsStack[currentCardIndex];
    if (!currentNews) return;
    
    setIsProcessing(true);
    const isCorrect = currentNews.type === decision;

    setExitDirection(decision === 'FACT' ? 'right' : 'left');

    if (isCorrect) {
      const bonus = Math.min(stats.correctStreak * 10, 50);
      const pointsAdded = 100 + bonus;
      
      showFeedback(`+${pointsAdded}`, 'plus');
      setStats(prev => ({
        ...prev,
        score: prev.score + pointsAdded,
        calmIndex: Math.min(100, prev.calmIndex + 5),
        correctStreak: prev.correctStreak + 1
      }));
      
      setTimeout(() => {
        setExitDirection(null);
        setCurrentCardIndex(prev => prev + 1);
        setIsProcessing(false);
      }, 400);
    } else {
      showFeedback(`-20 HP`, 'minus');
      setStats(prev => ({
        ...prev,
        battery: Math.max(0, prev.battery - 20),
        calmIndex: Math.max(0, prev.calmIndex - 15),
        correctStreak: 0
      }));
      
      setLastCorrection(currentNews);
      
      setTimeout(() => {
        setGameState(GameState.EDUCATION);
      }, 500);
    }
  };

  const handleContinue = () => {
    if (stats.battery <= 0) {
      setGameState(GameState.GAME_OVER);
    } else {
      setExitDirection(null);
      setCurrentCardIndex(prev => prev + 1);
      setIsProcessing(false);
      setGameState(GameState.PLAYING);
    }
  };

  const currentNews = newsStack[currentCardIndex];

  return (
    <div 
      className="fixed inset-0 w-full h-full flex items-center justify-center bg-[#050507] bg-center bg-cover bg-no-repeat overflow-hidden"
      style={{ backgroundImage: `url(${GAME_ASSETS.DESK_BG})` }}
    >
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-[12px] z-0"></div>
      
      <div 
        className="relative z-10 transition-transform duration-300 ease-out origin-center"
        style={{ transform: `scale(${scale})` }}
      >
        <PhoneFrame>
          {gameState === GameState.MENU && (
            <div className="flex-1 flex flex-col p-6 animate-in fade-in zoom-in duration-700 bg-slate-900/95 backdrop-blur-3xl">
              <div className="flex-1 flex flex-col items-center justify-center gap-2 mt-8">
                <div className="relative mb-6 text-center">
                  <div className="absolute inset-0 bg-blue-500 blur-[60px] opacity-20 animate-pulse"></div>
                  <div className="relative flex flex-col items-center select-none">
                    <span className="text-6xl font-black text-white tracking-[-0.1em] uppercase italic leading-none opacity-90">
                      CYBER
                    </span>
                    <span className="text-6xl font-black text-blue-500 tracking-[-0.1em] uppercase italic leading-none mt-[-8px] drop-shadow-[0_0_20px_rgba(59,130,246,0.8)]">
                      SHIELD
                    </span>
                    <div className="mt-4 flex items-center gap-2">
                      <div className="h-[1px] w-8 bg-blue-500/50"></div>
                      <span className="text-[10px] text-blue-300 font-black tracking-[0.4em] uppercase opacity-70">Anti-Hoax Bureau</span>
                      <div className="h-[1px] w-8 bg-blue-500/50"></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4 mb-16">
                <button 
                  onClick={startGame} 
                  className="w-full h-18 bg-gradient-to-br from-blue-500 to-blue-700 rounded-[28px] p-[1.5px] shadow-[0_15px_40px_rgba(0,0,0,0.6)] transition-all active:scale-95 group"
                >
                  <div className="w-full h-full bg-slate-950/40 rounded-[26.5px] flex items-center justify-center gap-4 hover:bg-transparent transition-colors py-4">
                    <div className="bg-white text-blue-700 p-3 rounded-full shadow-lg">
                      <Play size={24} fill="currentColor" />
                    </div>
                    <span className="text-white font-black uppercase tracking-[0.25em] text-2xl italic">Initialize</span>
                  </div>
                </button>

                <div className="grid grid-cols-2 gap-3">
                  <button className="h-15 bg-slate-800/40 rounded-2xl border border-slate-700/30 hover:bg-slate-700/60 transition-all active:scale-95 flex items-center justify-center gap-2 group backdrop-blur-md">
                    <Settings size={20} className="text-slate-400 group-hover:rotate-45 transition-transform" />
                    <span className="text-[11px] font-black text-slate-300 uppercase tracking-widest">Config</span>
                  </button>
                  <button 
                    onClick={() => setGameState(GameState.SHUTDOWN)}
                    className="h-15 bg-red-950/10 rounded-2xl border border-red-900/20 hover:bg-red-900/40 transition-all active:scale-95 flex items-center justify-center gap-2 group backdrop-blur-md"
                  >
                    <Skull size={20} className="text-red-600/70 group-hover:scale-110 transition-transform" />
                    <span className="text-[11px] font-black text-red-400/80 uppercase tracking-widest">Abort</span>
                  </button>
                </div>
              </div>

              <div className="text-center pb-8 flex flex-col items-center gap-2">
                <div className="text-[9px] text-slate-600 font-mono uppercase tracking-[0.6em] opacity-50">STATUS: ENCRYPTED_V7</div>
                <div className="flex gap-6 mt-1">
                   <button onClick={toggleMute} className="text-slate-500 hover:text-white transition-colors bg-slate-800/40 p-2.5 rounded-full border border-slate-700/20">
                      {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                   </button>
                </div>
              </div>
            </div>
          )}

          {gameState === GameState.PLAYING && (
            <div className="flex-1 flex flex-col h-full bg-slate-950 relative overflow-hidden">
              <div className="relative">
                <GameStats stats={stats} />
                <div className="absolute top-5 left-5 z-[50] flex gap-2">
                   <button 
                    onClick={toggleMute}
                    className="p-2 bg-slate-800/40 hover:bg-slate-800/60 rounded-full border border-slate-700/30 transition-colors group"
                  >
                    {isMuted ? <VolumeX size={18} className="text-slate-400" /> : <Volume2 size={18} className="text-blue-400" />}
                  </button>
                </div>
                <button 
                  onClick={exitGame}
                  className="absolute top-5 right-5 z-[50] p-2 bg-red-600/20 hover:bg-red-600/40 rounded-full border border-red-500/30 transition-colors group"
                >
                  <Power size={18} className="text-red-500 group-hover:scale-110 transition-transform" />
                </button>
              </div>
              
              <div className="flex-1 flex flex-col items-center p-5 relative bg-slate-900/40">
                {feedback && (
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[200] animate-in zoom-in duration-400 pointer-events-none">
                    <div className={`flex items-center gap-4 px-8 py-4 rounded-[32px] border-4 shadow-2xl backdrop-blur-3xl ${feedback.type === 'plus' ? 'bg-emerald-500/50 border-emerald-400 text-emerald-50' : 'bg-red-500/50 border-red-500 text-red-50'}`}>
                      {feedback.type === 'plus' ? <CheckCircle2 size={40} /> : <ShieldAlert size={40} />}
                      <span className="text-4xl font-black font-mono tracking-tighter">{feedback.text}</span>
                    </div>
                  </div>
                )}

                <div className="flex-1 w-full flex items-center justify-center py-4">
                  <div 
                    key={currentCardIndex}
                    className="relative w-full max-w-[280px] h-[410px] select-none z-10"
                    style={{
                      transform: exitDirection 
                        ? `translateX(${exitDirection === 'right' ? 550 : -550}px) rotate(${exitDirection === 'right' ? 35 : -35}deg)`
                        : `none`,
                      opacity: exitDirection ? 0 : 1,
                      transition: 'transform 0.5s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.4s ease-in'
                    }}
                  >
                    {currentNews ? (
                      <div className="w-full h-full bg-white rounded-[32px] shadow-2xl flex flex-col overflow-hidden border-2 border-slate-100">
                        <div className="h-4 bg-slate-50 border-b border-slate-100 flex items-center px-5">
                          <div className="w-2 h-2 rounded-full bg-slate-200"></div>
                        </div>
                        
                        <div className="h-40 bg-slate-200">
                          <ImageWithFallback 
                            src={currentNews.imageUrl} 
                            alt="News" 
                            className="w-full h-full object-cover" 
                          />
                        </div>

                        <div className="p-5 pt-3.5 flex-1 flex flex-col">
                          <div className="flex justify-between items-center mb-1.5">
                            <span className="text-[8px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded-full truncate max-w-[150px]">
                              {currentNews.source}
                            </span>
                          </div>
                          <h2 className="text-[14px] font-black text-slate-900 leading-[1.2] mb-2 line-clamp-2 tracking-tight">
                            {currentNews.headline}
                          </h2>
                          <div className="text-[10.5px] text-slate-600 leading-relaxed mb-1 flex-1 line-clamp-6 font-medium">
                            {currentNews.content}
                          </div>
                          
                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                            <div className="text-[7px] text-slate-400 truncate italic font-mono w-40">
                              {currentNews.url}
                            </div>
                            <RefreshCw size={10} className="text-slate-200" />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-full bg-slate-900 rounded-[32px] flex flex-col items-center justify-center p-8 text-center border-2 border-slate-800 shadow-inner">
                        <RefreshCw size={40} className="text-blue-500 animate-spin mb-5 opacity-60" />
                        <p className="text-[11px] font-black uppercase tracking-[0.3em] text-blue-400/70">SYNCING ARCHIVE...</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="w-full flex gap-4 mt-3 mb-6 h-24">
                  <button 
                    disabled={isProcessing || !currentNews}
                    onClick={() => handleDecision('HOAX')}
                    className="flex-1 bg-red-600 hover:bg-red-500 disabled:opacity-20 disabled:grayscale py-3.5 rounded-[32px] border-b-[6px] border-red-800 active:border-b-0 active:translate-y-1.5 transition-all flex flex-col items-center justify-center gap-1 shadow-lg group"
                  >
                    <X size={28} className="text-white group-hover:scale-125 transition-transform" strokeWidth={5} />
                    <span className="text-[9px] font-black text-white uppercase tracking-widest">REPORT HOAX</span>
                  </button>

                  <button 
                    disabled={isProcessing || !currentNews}
                    onClick={() => handleDecision('FACT')}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-20 disabled:grayscale py-3.5 rounded-[32px] border-b-[6px] border-emerald-800 active:border-b-0 active:translate-y-1.5 transition-all flex flex-col items-center justify-center gap-1 shadow-lg group"
                  >
                    <CheckCircle2 size={28} className="text-white group-hover:scale-125 transition-transform" strokeWidth={4} />
                    <span className="text-[9px] font-black text-white uppercase tracking-widest">VALIDATE FACT</span>
                  </button>
                </div>
              </div>

              {isGenerating && (
                <div className="absolute bottom-36 left-1/2 -translate-x-1/2 bg-blue-600 px-6 py-2.5 rounded-full border border-blue-400/50 backdrop-blur-lg flex items-center gap-3 z-[60] shadow-2xl animate-pulse pointer-events-none">
                  <RefreshCw size={12} className="text-white animate-spin" />
                  <span className="text-[9px] font-black text-white uppercase tracking-widest">FETCHING_DATA</span>
                </div>
              )}
            </div>
          )}

          {gameState === GameState.EDUCATION && lastCorrection && (
            <div className="flex-1 flex flex-col p-6 animate-in slide-in-from-bottom duration-500 h-full bg-slate-950">
              <div className="flex-1 overflow-y-auto space-y-5 py-3 scrollbar-hide">
                <div className="bg-red-500/20 p-4 rounded-[28px] border-2 border-red-500/40">
                  <div className="flex items-center gap-3 mb-1.5">
                    <AlertCircle size={24} className="text-red-500" />
                    <h2 className="text-md font-black uppercase text-white tracking-tight">SECURITY BREACH</h2>
                  </div>
                  <p className="text-[9px] text-red-300 font-bold uppercase tracking-[0.2em] opacity-80">VERIFICATION DATA LEAKED</p>
                </div>

                <div className="bg-slate-900/90 rounded-[28px] p-5 border border-slate-800 shadow-2xl">
                  <p className="text-[9px] text-slate-500 uppercase font-black mb-2 tracking-[0.3em]">ANALYSIS SUBJECT:</p>
                  <p className="text-[13px] font-bold text-slate-100 mb-5 leading-relaxed">{lastCorrection.headline}</p>
                  
                  <div className={`p-4 rounded-2xl border-2 flex items-center gap-4 ${lastCorrection.type === 'HOAX' ? 'bg-red-500/10 border-red-500/30' : 'bg-emerald-500/10 border-emerald-500/30'}`}>
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center shadow-xl ${lastCorrection.type === 'HOAX' ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white'}`}>
                      {lastCorrection.type === 'HOAX' ? <ShieldAlert size={32}/> : <CheckCircle2 size={32}/>}
                    </div>
                    <div>
                      <p className="text-[9px] text-slate-400 uppercase font-bold mb-0.5">TRUTH STATUS:</p>
                      <p className={`text-xl font-black uppercase tracking-tighter ${lastCorrection.type === 'HOAX' ? 'text-red-500' : 'text-emerald-500'}`}>
                        {lastCorrection.type}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-600/5 p-4 rounded-[24px] border border-blue-900/40">
                  <h4 className="text-[11px] text-blue-400 font-black uppercase mb-2 tracking-widest flex items-center gap-2">
                    <RefreshCw size={10} /> EXPERT_ANALYSIS:
                  </h4>
                  <p className="text-[12px] text-slate-300 leading-relaxed italic font-medium">
                    "{lastCorrection.explanation}"
                  </p>
                </div>
              </div>

              <button 
                onClick={handleContinue}
                className="w-full py-5 mt-4 bg-white text-slate-950 rounded-[32px] flex items-center justify-center gap-3 font-black uppercase transition-all active:scale-95 shadow-xl text-[14px] border-b-[6px] border-slate-300"
              >
                PROCEED <ChevronRight size={20} />
              </button>
            </div>
          )}

          {gameState === GameState.GAME_OVER && (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center animate-in zoom-in duration-500 bg-slate-950">
              <div className="relative mb-8">
                <div className="absolute inset-0 bg-red-600 blur-[50px] opacity-40 animate-pulse"></div>
                <div className="relative w-28 h-28 bg-red-600/15 text-red-500 rounded-[40px] flex items-center justify-center border-4 border-red-500/40">
                  <LogOut size={56} />
                </div>
              </div>
              
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-2">DISMISSED</h2>
              <p className="text-[11px] text-slate-500 mb-10 uppercase tracking-[0.5em] font-mono">CLEARANCE_REVOKED</p>

              <div className="w-full bg-slate-900/50 rounded-[32px] p-6 border border-slate-800 mb-10 shadow-inner">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] text-slate-500 uppercase font-black">LAST_RANK</span>
                  <span className="text-[12px] font-black text-blue-400 uppercase tracking-widest">{stats.rank}</span>
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-slate-800/60">
                  <span className="text-[10px] text-slate-500 uppercase font-black">FINAL_SCORE</span>
                  <span className="text-2xl font-black text-white font-mono tracking-tighter">{stats.score.toLocaleString()}</span>
                </div>
              </div>

              <button 
                onClick={startGame}
                className="w-full py-5 bg-blue-600 hover:bg-blue-500 rounded-[32px] text-white font-black uppercase transition-all active:scale-95 text-sm tracking-[0.3em] border-b-8 border-blue-800 shadow-xl"
              >
                RE-INITIALIZE
              </button>
            </div>
          )}
          
          {gameState === GameState.SHUTDOWN && (
            <div className="flex-1 flex flex-col items-center justify-center p-8 bg-black">
              <RefreshCw className="text-slate-900 animate-spin mb-8" size={56} />
              <p className="text-[11px] font-mono text-slate-800 uppercase tracking-[0.6em]">SYSTEM_HALTED</p>
              <button onClick={() => setGameState(GameState.MENU)} className="mt-14 text-[10px] text-slate-700 underline uppercase tracking-[0.2em] hover:text-slate-500">Restart_Database</button>
            </div>
          )}
        </PhoneFrame>
      </div>
    </div>
  );
};

export default App;
